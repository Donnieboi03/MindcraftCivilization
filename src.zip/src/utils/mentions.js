// src/utils/mentions.js
// CommonJS. If your project is ESM, switch to `export` syntax at the bottom.

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

/**
 * Build a mapping from alias (lowercased) -> canonical bot name.
 * knownBots: ["andy-4","gpt"]
 * aliasesByBot: { "andy-4": ["andy"], "gpt": ["chatgpt"] }
 */
function buildAliasMap(knownBots = [], aliasesByBot = {}) {
  const map = new Map();
  for (const name of knownBots) {
    map.set(name.toLowerCase(), name);
    const aliases = Array.isArray(aliasesByBot[name]) ? aliasesByBot[name] : [];
    for (const a of aliases) map.set(String(a).toLowerCase(), name);
  }
  return map;
}

/**
 * Extract { addressed, targets, command } from a chat message.
 * - addressed: should *this* bot act? (true/false)
 * - targets: array of canonical bot names mentioned
 * - command: cleaned command text (mentions stripped if they were at the start)
 */
function extractTargetsAndCommand(message, {
  thisBotName,
  knownBots = [],
  aliasesByBot = {}
} = {}) {
  const original = String(message ?? "");
  const aliasMap = buildAliasMap(knownBots, aliasesByBot);
  const namesAlt = Array.from(aliasMap.keys())
    .sort((a, b) => b.length - a.length) // match longer names first
    .map(escapeRegex)
    .join("|");

  if (!namesAlt) {
    // No gating configured: act on everything (preserves current behavior)
    return { addressed: true, targets: [], command: original.trim() };
  }

  const mentionRe = new RegExp(`\\b@?(?:${namesAlt})\\b`, "gi");
  const mentions = new Set();
  let m;
  while ((m = mentionRe.exec(original)) !== null) {
    const key = m[0].replace(/^@/, "").toLowerCase();
    const canonical = aliasMap.get(key);
    if (canonical) mentions.add(canonical);
  }

  if (mentions.size === 0) return { addressed: false, targets: [], command: "" };

  // If the message starts with a list of mentions, strip that header to form the command
  const startHeaderRe = new RegExp(
    `^(?:\\s*@?(?:${namesAlt})\\s*(?:,|\\band\\b|&)?\\s*)+[:,-]?\\s*`,
    "i"
  );
  const strippedStart = original.replace(startHeaderRe, "").trim();

  // Optional: also remove inline "@name," chunks like "hey @andy-4, build a house"
  const inlineCleanupRe = new RegExp(`\\b@?(?:${namesAlt})\\b\\s*[:,]?\\s*`, "gi");
  const cleaned =
    strippedStart.length > 0
      ? strippedStart
      : original.replace(inlineCleanupRe, "").trim();

  const addressed = thisBotName
    ? mentions.has(thisBotName)
    : true; // if thisBotName isn't supplied, treat as addressed

  return { addressed, targets: Array.from(mentions), command: cleaned || original.trim() };
}

module.exports = { extractTargetsAndCommand, buildAliasMap };
